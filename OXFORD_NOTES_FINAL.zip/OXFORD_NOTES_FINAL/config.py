"""
Configuration for Oxford LMS
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


def _db_url():
    """Return database URL, fixing Render's postgres:// → postgresql://"""
    url = os.environ.get('DATABASE_URL')
    if url:
        if url.startswith('postgres://'):
            url = url.replace('postgres://', 'postgresql://', 1)
        return url
    return f'sqlite:///{BASE_DIR}/database/oxford_notes.db'


class Config:
    # Security
    SECRET_KEY = os.environ.get('SECRET_KEY', 'oxford-lms-change-in-production-please')

    # Database
    SQLALCHEMY_DATABASE_URI = _db_url()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
    }

    # File uploads
    UPLOAD_FOLDER    = BASE_DIR / 'uploads'
    EXPORT_FOLDER    = BASE_DIR / 'exports'
    BACKUP_FOLDER    = BASE_DIR / 'backups'
    MAX_CONTENT_LENGTH = 50 * 1024 * 1024  # 50 MB

    ALLOWED_EXTENSIONS = {
        'pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx',
        'txt', 'png', 'jpg', 'jpeg', 'gif', 'zip'
    }

    # Sessions
    PERMANENT_SESSION_LIFETIME = 86400  # 24 hours

    # Branding
    APP_NAME    = 'OXFORD LMS'
    APP_VERSION = '4.0'

    # Create required directories
    for _folder in [UPLOAD_FOLDER, EXPORT_FOLDER, BACKUP_FOLDER]:
        _folder.mkdir(parents=True, exist_ok=True)
    for _sub in ['pdf', 'documents', 'presentations', 'spreadsheets',
                 'images', 'text', 'assignments', 'certificates', 'images/profiles']:
        (UPLOAD_FOLDER / _sub).mkdir(parents=True, exist_ok=True)


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False
    # Enforce env vars in production
    SECRET_KEY = os.environ.get('SECRET_KEY') or Config.SECRET_KEY


config_by_name = {
    'development': DevelopmentConfig,
    'production':  ProductionConfig,
    'default':     DevelopmentConfig,
}

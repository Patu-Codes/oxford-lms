"""WSGI entry point for Gunicorn / production servers"""
from web_app import app

if __name__ == '__main__':
    app.run()

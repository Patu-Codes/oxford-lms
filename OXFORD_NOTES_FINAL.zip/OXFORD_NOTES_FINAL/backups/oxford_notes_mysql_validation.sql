-- OXFORD NOTES MySQL backup
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `details` varchar(255) DEFAULT '',
  `status` varchar(255) DEFAULT 'SUCCESS',
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (1,1,'LOGIN FAILED','admin','FAILED','2026-09-10 19:53:40');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (2,NULL,'LOGIN FAILED','dhanu@07','FAILED','2026-09-10 19:53:58');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (3,1,'LOGIN FAILED','admin','FAILED','2026-09-11 18:49:24');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (4,1,'LOGIN FAILED','admin','FAILED','2026-09-11 18:49:35');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (5,NULL,'LOGIN FAILED','dhanu@07','FAILED','2026-09-11 18:49:57');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (6,1,'LOGIN','ADMIN login','SUCCESS','2026-09-11 18:51:02');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (7,1,'LOGOUT','ADMIN logout','SUCCESS','2026-09-11 18:51:18');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (8,1,'LOGIN','ADMIN login','SUCCESS','2026-09-11 18:51:37');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (9,1,'STUDENT ADDED','101','SUCCESS','2026-09-11 18:52:48');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (10,1,'NOTE UPLOAD','1st and 2nd lecture theory','SUCCESS','2026-09-11 18:53:35');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (11,1,'PERMISSION CHANGED','Student 3: 1 note permissions','SUCCESS','2026-09-11 18:54:14');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (12,1,'NOTE UPLOAD','Data Structures L-4','SUCCESS','2026-09-11 18:54:30');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (13,1,'PERMISSION CHANGED','Student 3: 1 note permissions','SUCCESS','2026-09-11 18:54:45');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (14,1,'PERMISSION CHANGED','Student 3: 1 note permissions','SUCCESS','2026-09-11 18:54:49');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (15,1,'LOGOUT','ADMIN logout','SUCCESS','2026-09-11 18:54:51');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (16,3,'LOGIN','STUDENT login','SUCCESS','2026-09-11 18:55:08');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (17,3,'NOTE OPEN','1st and 2nd lecture theory','SUCCESS','2026-09-11 18:55:17');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (18,3,'LOGOUT','STUDENT logout','SUCCESS','2026-09-11 18:55:24');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (19,1,'LOGIN','ADMIN login','SUCCESS','2026-09-11 18:55:45');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (20,1,'LOGOUT','ADMIN logout','SUCCESS','2026-09-11 18:58:05');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (21,1,'LOGIN','ADMIN login','SUCCESS','2026-09-11 18:59:50');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (22,1,'STUDENT ADDED','102','SUCCESS','2026-09-11 19:03:42');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (23,1,'STUDENT ADDED','103','SUCCESS','2026-09-11 19:04:58');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (24,1,'PERMISSION CHANGED','Student 5: 1 note permissions','SUCCESS','2026-09-11 19:05:19');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (25,1,'LOGOUT','ADMIN logout','SUCCESS','2026-09-11 19:05:27');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (26,NULL,'LOGIN FAILED','ashwini@01','FAILED','2026-09-11 19:05:42');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (27,NULL,'LOGIN FAILED','ashwini@01','FAILED','2026-09-11 19:05:59');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (28,NULL,'LOGIN FAILED','ashwini@01','FAILED','2026-09-11 19:06:05');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (29,1,'LOGIN','ADMIN login','SUCCESS','2026-09-11 19:06:25');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (30,1,'STUDENT UPDATED','103','SUCCESS','2026-09-11 19:06:53');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (31,1,'LOGOUT','ADMIN logout','SUCCESS','2026-09-11 19:06:55');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (32,NULL,'LOGIN FAILED','ashwini@01','FAILED','2026-09-11 19:07:14');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (33,NULL,'LOGIN FAILED','vaibhavi@01','FAILED','2026-09-11 19:07:43');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (34,NULL,'LOGIN FAILED','vaibhavi@01','FAILED','2026-09-11 19:07:55');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (35,NULL,'LOGIN FAILED','dhanu@01','FAILED','2026-09-11 19:08:08');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (36,1,'LOGIN','ADMIN login','SUCCESS','2026-09-11 19:08:27');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (37,1,'STUDENT UPDATED','102','SUCCESS','2026-09-11 19:09:11');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (38,1,'LOGOUT','ADMIN logout','SUCCESS','2026-09-11 19:09:20');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (39,NULL,'LOGIN FAILED','vaibhavi@01','FAILED','2026-09-11 19:09:47');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (40,1,'LOGIN','ADMIN login','SUCCESS','2026-09-11 19:10:06');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (41,1,'NOTE UPLOAD','Exception Handling','SUCCESS','2026-09-11 19:10:36');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (42,1,'STUDENT UPDATED','101','SUCCESS','2026-09-11 19:14:10');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (43,1,'LOGOUT','ADMIN logout','SUCCESS','2026-09-11 19:14:14');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (44,3,'LOGIN','STUDENT login','SUCCESS','2026-09-11 19:15:33');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (45,3,'LOGOUT','STUDENT logout','SUCCESS','2026-09-11 19:16:35');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (46,1,'LOGIN','ADMIN login','SUCCESS','2026-09-21 19:21:08');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (47,1,'LOGOUT','ADMIN logout','SUCCESS','2026-09-21 19:24:12');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (48,NULL,'LOGIN FAILED','apoorva123','FAILED','2026-09-21 19:24:39');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (49,1,'LOGIN','ADMIN login','SUCCESS','2026-09-21 19:25:07');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (50,1,'LOGOUT','ADMIN logout','SUCCESS','2026-09-21 19:25:24');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (51,1,'LOGIN','ADMIN login','SUCCESS','2026-09-21 19:27:36');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (52,1,'STUDENT ADDED','105','SUCCESS','2026-09-21 19:29:14');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (53,1,'LOGOUT','ADMIN logout','SUCCESS','2026-09-21 19:29:18');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (54,6,'LOGIN','STUDENT login','SUCCESS','2026-09-21 19:29:38');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (55,6,'LOGOUT','STUDENT logout','SUCCESS','2026-09-21 19:29:46');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (56,1,'LOGIN','ADMIN login','SUCCESS','2026-09-21 19:41:24');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (57,1,'PERMISSION CHANGED','Student 6: 2 note permissions','SUCCESS','2026-09-21 19:42:00');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (58,1,'LOGOUT','ADMIN logout','SUCCESS','2026-09-21 19:42:16');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (59,6,'LOGIN FAILED','dhanu@123','FAILED','2026-09-21 19:42:26');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (60,6,'LOGIN','STUDENT login','SUCCESS','2026-09-21 19:42:34');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (61,6,'LOGOUT','STUDENT logout','SUCCESS','2026-09-21 19:47:13');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (62,1,'LOGIN','ADMIN login','SUCCESS','2026-09-21 22:18:37');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (63,1,'NOTE UPLOAD','Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F','SUCCESS','2026-09-21 22:21:52');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (64,1,'NOTE OPEN','Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F','SUCCESS','2026-09-21 22:21:56');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (65,1,'NOTE OPEN','Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F','SUCCESS','2026-09-21 22:21:57');
INSERT IGNORE INTO `activity_logs` (`id`,`user_id`,`action`,`details`,`status`,`created_at`) VALUES (66,1,'NOTE OPEN','Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F','SUCCESS','2026-09-21 22:22:04');

CREATE TABLE IF NOT EXISTS `bookmarks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `note_id` int NOT NULL,
  `page` int DEFAULT '1',
  `label` varchar(255) DEFAULT '',
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_note_page` (`user_id`,`note_id`,`page`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT IGNORE INTO `categories` (`id`,`name`) VALUES (1,'CA');
INSERT IGNORE INTO `categories` (`id`,`name`) VALUES (3,'Computer');
INSERT IGNORE INTO `categories` (`id`,`name`) VALUES (7,'Data Science');
INSERT IGNORE INTO `categories` (`id`,`name`) VALUES (4,'Exam Revision');
INSERT IGNORE INTO `categories` (`id`,`name`) VALUES (5,'Python');
INSERT IGNORE INTO `categories` (`id`,`name`) VALUES (6,'SQL');
INSERT IGNORE INTO `categories` (`id`,`name`) VALUES (2,'Tuition');

CREATE TABLE IF NOT EXISTS `downloads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `note_id` int DEFAULT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `favorites` (
  `student_id` int NOT NULL,
  `note_id` int NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`student_id`,`note_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `learning_progress` (
  `user_id` int NOT NULL,
  `xp` int DEFAULT '0',
  `streak_days` int DEFAULT '0',
  `last_activity` varchar(255) DEFAULT '',
  `badges` text,
  `updated_at` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT '',
  `filename` varchar(255) NOT NULL,
  `filepath` varchar(255) NOT NULL,
  `category_id` int DEFAULT NULL,
  `description` varchar(255) DEFAULT '',
  `author` varchar(255) DEFAULT '',
  `tags` varchar(255) DEFAULT '',
  `uploaded_by` int DEFAULT NULL,
  `uploaded_at` varchar(255) NOT NULL,
  `size` int DEFAULT '0',
  `file_hash` varchar(255) DEFAULT '',
  `starred` int DEFAULT '0',
  `status` varchar(255) DEFAULT 'Active',
  `module` varchar(255) DEFAULT '',
  `topic` varchar(255) DEFAULT '',
  `semester` varchar(255) DEFAULT '',
  `division` varchar(255) DEFAULT '',
  `faculty` varchar(255) DEFAULT '',
  `difficulty` varchar(50) DEFAULT 'Medium',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT IGNORE INTO `notes` (`id`,`title`,`subject`,`filename`,`filepath`,`category_id`,`description`,`author`,`tags`,`uploaded_by`,`uploaded_at`,`size`,`file_hash`,`starred`,`status`,`module`,`topic`,`semester`,`division`,`faculty`,`difficulty`) VALUES (1,'1st and 2nd lecture theory','PYTHON','1st and 2nd lecture theory.pdf','C:\\Users\\Administrator\\Desktop\\OXFORD_NOTES_FINAL\\uploads\\pdf\\1st and 2nd lecture theory.pdf',7,'','System Administrator','1',1,'2026-09-11 18:53:35',20757,'be5165b124c1e1148042215c19e5219a68aeececde359f267c1842220ab51baf',0,'Active','','','','','','Medium');
INSERT IGNORE INTO `notes` (`id`,`title`,`subject`,`filename`,`filepath`,`category_id`,`description`,`author`,`tags`,`uploaded_by`,`uploaded_at`,`size`,`file_hash`,`starred`,`status`,`module`,`topic`,`semester`,`division`,`faculty`,`difficulty`) VALUES (2,'Data Structures L-4','DATA','Data Structures L-4.pdf','C:\\Users\\Administrator\\Desktop\\OXFORD_NOTES_FINAL\\uploads\\pdf\\Data Structures L-4.pdf',1,'','System Administrator','',1,'2026-09-11 18:54:30',65720,'552d4621290782eb453ba75ccac51cf018af2efb35d7ed6dbccac377c4917ef4',0,'Active','','','','','','Medium');
INSERT IGNORE INTO `notes` (`id`,`title`,`subject`,`filename`,`filepath`,`category_id`,`description`,`author`,`tags`,`uploaded_by`,`uploaded_at`,`size`,`file_hash`,`starred`,`status`,`module`,`topic`,`semester`,`division`,`faculty`,`difficulty`) VALUES (3,'Exception Handling','python','Exception Handling.pdf','C:\\Users\\Administrator\\Desktop\\OXFORD_NOTES_FINAL\\uploads\\pdf\\Exception Handling.pdf',7,'','System Administrator','',1,'2026-09-11 19:10:36',81869,'82252390198862bf23110abe1f1ab11f3fa9efe7335219a9da622cdcbe145583',0,'Active','','','','','','Medium');
INSERT IGNORE INTO `notes` (`id`,`title`,`subject`,`filename`,`filepath`,`category_id`,`description`,`author`,`tags`,`uploaded_by`,`uploaded_at`,`size`,`file_hash`,`starred`,`status`,`module`,`topic`,`semester`,`division`,`faculty`,`difficulty`) VALUES (4,'Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F','field project','Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F.docx','C:\\Users\\DHANUSHREE PATIL\\Downloads\\OXFORD_NOTES_FINAL_OXFORD_BRANDED\\OXFORD_NOTES_FINAL\\uploads\\documents\\Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F.docx',1,'','System Administrator','',1,'2026-09-21 22:21:52',1508578,'2d0e61b65543a6929aea4590b25519ef33ee12f5defdd56243a5aafef13f9b8f',0,'Active','1','1','1','','System Administrator','Medium');

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `message` varchar(255) DEFAULT '',
  `is_read` int DEFAULT '0',
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (1,1,'New student registered','dhanu',0,'2026-09-11 18:52:48');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (2,2,'New student registered','dhanu',0,'2026-09-11 18:52:48');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (3,3,'New student registered','dhanu',0,'2026-09-11 18:52:48');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (4,1,'New note uploaded','1st and 2nd lecture theory',0,'2026-09-11 18:53:35');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (5,2,'New note uploaded','1st and 2nd lecture theory',0,'2026-09-11 18:53:35');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (6,3,'New note uploaded','1st and 2nd lecture theory',0,'2026-09-11 18:53:35');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (7,1,'Permission changed','Student 3',0,'2026-09-11 18:54:14');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (8,2,'Permission changed','Student 3',0,'2026-09-11 18:54:14');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (9,3,'Permission changed','Student 3',0,'2026-09-11 18:54:14');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (10,1,'New note uploaded','Data Structures L-4',0,'2026-09-11 18:54:30');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (11,2,'New note uploaded','Data Structures L-4',0,'2026-09-11 18:54:30');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (12,3,'New note uploaded','Data Structures L-4',0,'2026-09-11 18:54:30');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (13,1,'Permission changed','Student 3',0,'2026-09-11 18:54:45');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (14,2,'Permission changed','Student 3',0,'2026-09-11 18:54:45');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (15,3,'Permission changed','Student 3',0,'2026-09-11 18:54:45');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (16,1,'Permission changed','Student 3',0,'2026-09-11 18:54:49');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (17,2,'Permission changed','Student 3',0,'2026-09-11 18:54:49');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (18,3,'Permission changed','Student 3',0,'2026-09-11 18:54:49');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (19,1,'New student registered','vaibhavi',0,'2026-09-11 19:03:42');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (20,2,'New student registered','vaibhavi',0,'2026-09-11 19:03:42');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (21,3,'New student registered','vaibhavi',0,'2026-09-11 19:03:42');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (22,4,'New student registered','vaibhavi',0,'2026-09-11 19:03:42');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (23,1,'New student registered','ashwini',0,'2026-09-11 19:04:58');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (24,2,'New student registered','ashwini',0,'2026-09-11 19:04:58');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (25,3,'New student registered','ashwini',0,'2026-09-11 19:04:58');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (26,4,'New student registered','ashwini',0,'2026-09-11 19:04:58');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (27,5,'New student registered','ashwini',0,'2026-09-11 19:04:58');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (28,1,'Permission changed','Student 5',0,'2026-09-11 19:05:19');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (29,2,'Permission changed','Student 5',0,'2026-09-11 19:05:19');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (30,3,'Permission changed','Student 5',0,'2026-09-11 19:05:19');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (31,4,'Permission changed','Student 5',0,'2026-09-11 19:05:19');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (32,5,'Permission changed','Student 5',0,'2026-09-11 19:05:19');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (33,1,'Student updated','ashwini',0,'2026-09-11 19:06:53');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (34,2,'Student updated','ashwini',0,'2026-09-11 19:06:53');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (35,3,'Student updated','ashwini',0,'2026-09-11 19:06:53');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (36,4,'Student updated','ashwini',0,'2026-09-11 19:06:53');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (37,5,'Student updated','ashwini',0,'2026-09-11 19:06:53');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (38,1,'Student updated','vaibhavi',0,'2026-09-11 19:09:11');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (39,2,'Student updated','vaibhavi',0,'2026-09-11 19:09:11');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (40,3,'Student updated','vaibhavi',0,'2026-09-11 19:09:11');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (41,4,'Student updated','vaibhavi',0,'2026-09-11 19:09:11');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (42,5,'Student updated','vaibhavi',0,'2026-09-11 19:09:11');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (43,1,'New note uploaded','Exception Handling',0,'2026-09-11 19:10:36');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (44,2,'New note uploaded','Exception Handling',0,'2026-09-11 19:10:36');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (45,3,'New note uploaded','Exception Handling',0,'2026-09-11 19:10:36');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (46,4,'New note uploaded','Exception Handling',0,'2026-09-11 19:10:36');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (47,5,'New note uploaded','Exception Handling',0,'2026-09-11 19:10:36');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (48,1,'Student updated','dhanu',0,'2026-09-11 19:14:10');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (49,2,'Student updated','dhanu',0,'2026-09-11 19:14:10');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (50,3,'Student updated','dhanu',0,'2026-09-11 19:14:10');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (51,4,'Student updated','dhanu',0,'2026-09-11 19:14:10');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (52,5,'Student updated','dhanu',0,'2026-09-11 19:14:10');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (53,1,'New student registered','dhanushree',0,'2026-09-21 19:29:14');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (54,2,'New student registered','dhanushree',0,'2026-09-21 19:29:14');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (55,3,'New student registered','dhanushree',0,'2026-09-21 19:29:14');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (56,4,'New student registered','dhanushree',0,'2026-09-21 19:29:14');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (57,5,'New student registered','dhanushree',0,'2026-09-21 19:29:14');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (58,6,'New student registered','dhanushree',0,'2026-09-21 19:29:14');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (59,1,'Permission changed','Student 6',0,'2026-09-21 19:42:00');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (60,2,'Permission changed','Student 6',0,'2026-09-21 19:42:00');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (61,3,'Permission changed','Student 6',0,'2026-09-21 19:42:00');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (62,4,'Permission changed','Student 6',0,'2026-09-21 19:42:00');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (63,5,'Permission changed','Student 6',0,'2026-09-21 19:42:00');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (64,6,'Permission changed','Student 6',0,'2026-09-21 19:42:00');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (65,1,'New note uploaded','Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F',0,'2026-09-21 22:21:52');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (66,2,'New note uploaded','Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F',0,'2026-09-21 22:21:52');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (67,3,'New note uploaded','Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F',0,'2026-09-21 22:21:52');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (68,4,'New note uploaded','Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F',0,'2026-09-21 22:21:52');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (69,5,'New note uploaded','Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F',0,'2026-09-21 22:21:52');
INSERT IGNORE INTO `notifications` (`id`,`user_id`,`title`,`message`,`is_read`,`created_at`) VALUES (70,6,'New note uploaded','Aadhaar_PAN_Digital_ID_Field_Project_Final_Appendices_A_to_F',0,'2026-09-21 22:21:52');

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `note_id` int NOT NULL,
  `can_view` int DEFAULT '1',
  `can_download` int DEFAULT '1',
  `can_upload` int DEFAULT '0',
  `can_edit` int DEFAULT '0',
  `can_delete` int DEFAULT '0',
  `granted_by` int DEFAULT NULL,
  `granted_at` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `student_id` (`student_id`,`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT IGNORE INTO `permissions` (`id`,`student_id`,`note_id`,`can_view`,`can_download`,`can_upload`,`can_edit`,`can_delete`,`granted_by`,`granted_at`) VALUES (3,3,1,1,0,0,0,0,1,'2026-09-11 18:54:49');
INSERT IGNORE INTO `permissions` (`id`,`student_id`,`note_id`,`can_view`,`can_download`,`can_upload`,`can_edit`,`can_delete`,`granted_by`,`granted_at`) VALUES (4,5,2,1,1,0,0,0,1,'2026-09-11 19:05:19');
INSERT IGNORE INTO `permissions` (`id`,`student_id`,`note_id`,`can_view`,`can_download`,`can_upload`,`can_edit`,`can_delete`,`granted_by`,`granted_at`) VALUES (5,6,2,0,1,0,0,0,1,'2026-09-21 19:42:00');
INSERT IGNORE INTO `permissions` (`id`,`student_id`,`note_id`,`can_view`,`can_download`,`can_upload`,`can_edit`,`can_delete`,`granted_by`,`granted_at`) VALUES (6,6,3,0,1,0,0,0,1,'2026-09-21 19:42:00');

CREATE TABLE IF NOT EXISTS `quiz_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `subject` varchar(255) DEFAULT '',
  `difficulty` varchar(50) DEFAULT '',
  `total_questions` int DEFAULT '0',
  `correct_answers` int DEFAULT '0',
  `score` decimal(8,2) DEFAULT '0.00',
  `duration_seconds` int DEFAULT '0',
  `completed_at` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `quiz_questions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL,
  `module` varchar(255) DEFAULT '',
  `difficulty` varchar(50) DEFAULT 'Medium',
  `question` text NOT NULL,
  `option_a` text NOT NULL,
  `option_b` text NOT NULL,
  `option_c` text NOT NULL,
  `option_d` text NOT NULL,
  `answer` varchar(10) NOT NULL,
  `explanation` text,
  `created_by` int DEFAULT NULL,
  `created_at` varchar(255) NOT NULL,
  `status` varchar(50) DEFAULT 'Active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `settings` (
  `key` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('accent','');
INSERT IGNORE INTO `settings` (`key`,`value`) VALUES ('theme','Oxford Royal');

CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'student',
  `full_name` varchar(255) NOT NULL,
  `class_name` varchar(255) DEFAULT '',
  `email` varchar(255) DEFAULT '',
  `course` varchar(255) DEFAULT '',
  `year` varchar(255) DEFAULT '',
  `phone` varchar(255) DEFAULT '',
  `student_id` varchar(255) DEFAULT '',
  `status` varchar(255) DEFAULT 'Active',
  `created_at` varchar(255) NOT NULL,
  `last_login` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT IGNORE INTO `users` (`id`,`username`,`password`,`role`,`full_name`,`class_name`,`email`,`course`,`year`,`phone`,`student_id`,`status`,`created_at`,`last_login`) VALUES (1,'admin','104f7d7a204f8b76d3238fdcd3eed63b$58bec77c7158f136eb6573465c1e4eab44d6b7753bc8671c62921f7b703f49c0','admin','System Administrator','','','','','','','Active','2026-09-21 18:56:43',NULL);
INSERT IGNORE INTO `users` (`id`,`username`,`password`,`role`,`full_name`,`class_name`,`email`,`course`,`year`,`phone`,`student_id`,`status`,`created_at`,`last_login`) VALUES (2,'librarian','cf3104b015b9d9bf8501eecde821f6b8$e7d432d09e0a261a07742d90519819210931b121701d1d472afcef276ac25584','librarian','Oxford Librarian','','','','','','','Active','2026-09-21 18:56:43',NULL);
INSERT IGNORE INTO `users` (`id`,`username`,`password`,`role`,`full_name`,`class_name`,`email`,`course`,`year`,`phone`,`student_id`,`status`,`created_at`,`last_login`) VALUES (3,'dhanu@07','fbec1c3ae3bbb14bbabb7802673bc635$64d787eb471791a4759fd75be3e5a901a01b038a82d136a739f8ff6f78b1d38b','student','dhanu','2027','dhanu@gmail.com','data anlytics','2027','548645321','101','Active','2026-09-11 18:52:48','2026-09-11 19:15:33');
INSERT IGNORE INTO `users` (`id`,`username`,`password`,`role`,`full_name`,`class_name`,`email`,`course`,`year`,`phone`,`student_id`,`status`,`created_at`,`last_login`) VALUES (4,'vaibhavi123','508a70369d2d688f15a8535abc06d715$e5a5f469dd5fd06cbdb2905fefa602099b7cf8c1ad2fcf8e9727b114c7a26700','student','vaibhavi','2007','vaibhavi@gmail.com','python','2007','5484541854152','102','Active','2026-09-11 19:03:42',NULL);
INSERT IGNORE INTO `users` (`id`,`username`,`password`,`role`,`full_name`,`class_name`,`email`,`course`,`year`,`phone`,`student_id`,`status`,`created_at`,`last_login`) VALUES (5,'ashwinikat@01','b28b691f375a0530331ace1f48c3b95a$9c8000b1db8f6d4109d232830f8a664c0e47db138978f810702f0161241feee1','student','ashwini','1995','ashwini@gmail.com','data anlystic','1995','56485451222','103','Active','2026-09-11 19:04:58',NULL);
INSERT IGNORE INTO `users` (`id`,`username`,`password`,`role`,`full_name`,`class_name`,`email`,`course`,`year`,`phone`,`student_id`,`status`,`created_at`,`last_login`) VALUES (6,'dhanu@123','e86840a4e571921c63c923535386f4d1$67583a0035478b6df7ef3411a748bccaf612e01e89b918e719bce8995fc9ccb5','student','dhanushree','2026','dhanushree@gmail.com','data anlytics','2026','236762376237','105','Active','2026-09-21 19:29:14','2026-09-21 19:42:34');

CREATE TABLE IF NOT EXISTS `views` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `note_id` int DEFAULT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT IGNORE INTO `views` (`id`,`user_id`,`note_id`,`created_at`) VALUES (1,3,1,'2026-09-11 18:55:17');
INSERT IGNORE INTO `views` (`id`,`user_id`,`note_id`,`created_at`) VALUES (2,1,4,'2026-09-21 22:21:56');
INSERT IGNORE INTO `views` (`id`,`user_id`,`note_id`,`created_at`) VALUES (3,1,4,'2026-09-21 22:21:57');
INSERT IGNORE INTO `views` (`id`,`user_id`,`note_id`,`created_at`) VALUES (4,1,4,'2026-09-21 22:22:04');

SET FOREIGN_KEY_CHECKS=1;

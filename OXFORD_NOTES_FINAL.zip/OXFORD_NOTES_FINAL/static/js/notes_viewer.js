/**
 * Oxford LMS — Protected Document Viewer
 *
 * PDF files: rendered with PDF.js (canvas-based, no browser toolbar).
 * DOCX/PPTX/XLSX: displayed via Google Docs Viewer (read-only embed).
 * Other: unsupported message.
 *
 * Controls: zoom in/out, page navigation, scroll only.
 * Removed: print, save, annotations, open-in-new-tab.
 *
 * Security note: OS-level screenshots cannot be prevented in a web browser.
 * These controls are deterrence, not DRM.
 */

(function () {
  'use strict';

  const GDOCS_TYPES = new Set(['doc','docx','ppt','pptx','xls','xlsx','odt','rtf','csv']);
  const PDF_TYPE    = 'pdf';
  const IMAGE_TYPES = new Set(['png','jpg','jpeg','gif','webp','svg']);

  // ── PDF.js state ────────────────────────────────────────────────────────
  let _pdfDoc     = null;
  let _pageNum    = 1;
  let _pageCount  = 0;
  let _scale      = 1.2;
  let _renderTask = null;
  let _noteId     = null;

  // ── Helpers ─────────────────────────────────────────────────────────────
  function esc(s) {
    if (!s) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  // ── Main entry ───────────────────────────────────────────────────────────
  window.openNoteViewer = function (note, user) {
    const existing = document.getElementById('noteViewerOverlay');
    if (existing) existing.remove();
    _removeHandlers();

    _noteId    = note.id;
    _scale     = 1.2;
    _pageNum   = 1;
    _pdfDoc    = null;

    const isViewOnly    = !note.is_downloadable;
    const isStudent     = user.role === 'student';
    const showWatermark = isViewOnly && isStudent;
    const ft            = (note.file_type || '').toLowerCase();

    const canDl = (!isViewOnly || user.role === 'admin');

    const wmName = esc(user.full_name || user.username || '');
    const wmId   = esc(user.username || '');

    // ── Toolbar ─────────────────────────────────────────────────────────
    const dlBtn = canDl
      ? `<button onclick="downloadNoteFromViewer(${note.id})" style="
           padding:5px 14px;background:#2563eb;color:#fff;border:none;
           border-radius:5px;font-size:12px;font-weight:600;cursor:pointer;">
           Download</button>`
      : '';

    // PDF-specific toolbar extras (hidden for non-PDF)
    const pdfControls = ft === PDF_TYPE ? `
      <div id="pdfToolbar" style="
        display:flex;align-items:center;gap:6px;
        padding:0 16px;height:100%;border-left:1px solid rgba(255,255,255,.1);
      ">
        <button id="zoomOut"  class="vtbtn" title="Zoom out"  onclick="pdfZoom(-0.2)">&#8722;</button>
        <span id="zoomLabel" style="
          font-size:12px;color:rgba(255,255,255,.7);min-width:38px;text-align:center;">
          120%</span>
        <button id="zoomIn"   class="vtbtn" title="Zoom in"   onclick="pdfZoom(+0.2)">&#43;</button>
        <div style="width:1px;height:20px;background:rgba(255,255,255,.15);margin:0 4px;"></div>
        <button id="prevPage" class="vtbtn" title="Previous page" onclick="pdfPrevPage()">&#8592;</button>
        <span id="pageInfo"  style="font-size:12px;color:rgba(255,255,255,.7);min-width:52px;text-align:center;">
          1 / 1</span>
        <button id="nextPage" class="vtbtn" title="Next page"     onclick="pdfNextPage()">&#8594;</button>
      </div>` : '';

    // ── Viewer body ─────────────────────────────────────────────────────
    let bodyHtml = '';

    if (ft === PDF_TYPE) {
      bodyHtml = `
        <!-- PDF canvas scroll container -->
        <div id="pdfScrollContainer" style="
          width:100%;height:100%;overflow-y:auto;overflow-x:auto;
          background:#404040;display:flex;flex-direction:column;
          align-items:center;padding:16px 0;box-sizing:border-box;
          scroll-behavior:smooth;
        ">
          <canvas id="pdfCanvas" style="
            display:block;box-shadow:0 4px 20px rgba(0,0,0,.5);
            max-width:none;
          "></canvas>
        </div>`;

    } else if (IMAGE_TYPES.has(ft)) {
      bodyHtml = `
        <div style="width:100%;height:100%;overflow:auto;display:flex;
                    align-items:center;justify-content:center;background:#404040;">
          <img src="/api/notes/${note.id}/view"
               style="max-width:100%;max-height:100%;object-fit:contain;"
               alt="${esc(note.title)}">
        </div>`;

    } else if (GDOCS_TYPES.has(ft)) {
      const fileUrl = encodeURIComponent(`${location.origin}/api/notes/${note.id}/view`);
      bodyHtml = `
        <div id="gdocsSpinner" style="
          position:absolute;inset:0;display:flex;flex-direction:column;
          align-items:center;justify-content:center;
          background:#2a2a2a;color:#fff;gap:12px;z-index:5;">
          <div style="width:32px;height:32px;border-radius:50%;
                      border:3px solid rgba(255,255,255,.2);border-top-color:#f59e0b;
                      animation:_olSpin .8s linear infinite;"></div>
          <div style="font-size:13px;opacity:.8;">Loading preview&hellip;</div>
        </div>
        <iframe src="https://docs.google.com/viewer?url=${fileUrl}&embedded=true"
          style="width:100%;height:100%;border:none;display:block;"
          onload="var s=document.getElementById('gdocsSpinner');if(s)s.remove();"
          title="${esc(note.title)}"></iframe>`;

    } else {
      bodyHtml = `
        <div style="display:flex;flex-direction:column;align-items:center;
                    justify-content:center;height:100%;color:#fff;gap:16px;text-align:center;padding:40px;">
          <div style="font-size:48px;opacity:.3;">&#x1F4C4;</div>
          <div style="font-size:15px;font-weight:600;">
            Cannot preview .${esc(note.file_type || '?')} files in the browser</div>
          <div style="font-size:13px;opacity:.6;">
            This file format cannot be displayed inline.</div>
          ${canDl ? `<button onclick="downloadNoteFromViewer(${note.id})" style="
            margin-top:8px;padding:10px 24px;background:#2563eb;color:#fff;
            border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;">
            Download to view</button>` : `
          <div style="font-size:12px;opacity:.45;margin-top:4px;">
            This note is View Only — contact your instructor.</div>`}
        </div>`;
    }

    // ── Watermark ────────────────────────────────────────────────────────
    const watermarkHtml = showWatermark ? `
      <div style="
        position:absolute;inset:0;pointer-events:none;overflow:hidden;
        display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:repeat(5,1fr);
        z-index:50;">
        ${Array(15).fill(`
          <div style="display:flex;align-items:center;justify-content:center;
            transform:rotate(-32deg);opacity:.055;
            font-size:10px;font-weight:900;color:#0f2340;
            white-space:nowrap;pointer-events:none;user-select:none;
            text-align:center;line-height:1.7;">
            OXFORD LMS<br>${wmName}<br>${wmId}</div>
        `).join('')}
      </div>` : '';

    // ── Shield (view-only) ───────────────────────────────────────────────
    // Only for non-PDF; PDF uses canvas which already blocks native context menus
    const shieldHtml = (isViewOnly && ft !== PDF_TYPE) ? `
      <div id="viewerShield" style="
        position:absolute;inset:0;z-index:40;cursor:default;background:transparent;">
      </div>` : '';

    // ── Assemble ─────────────────────────────────────────────────────────
    const overlay = document.createElement('div');
    overlay.id    = 'noteViewerOverlay';
    overlay.style.cssText = `
      position:fixed;inset:0;z-index:9000;
      background:rgba(10,20,40,.88);
      display:flex;flex-direction:column;
      font-family:'Inter',-apple-system,sans-serif;
    `;

    overlay.innerHTML = `
      <style>
        @keyframes _olSpin { to { transform:rotate(360deg); } }
        .vtbtn {
          width:28px;height:28px;background:rgba(255,255,255,.1);
          border:none;color:#fff;border-radius:5px;
          font-size:16px;line-height:1;cursor:pointer;
          display:flex;align-items:center;justify-content:center;
          transition:background .15s;
        }
        .vtbtn:hover { background:rgba(255,255,255,.22); }
        .vtbtn:active { background:rgba(255,255,255,.3); }
        #pdfScrollContainer::-webkit-scrollbar { width:8px;height:8px; }
        #pdfScrollContainer::-webkit-scrollbar-track { background:#333; }
        #pdfScrollContainer::-webkit-scrollbar-thumb { background:#666;border-radius:4px; }
        #pdfScrollContainer::-webkit-scrollbar-thumb:hover { background:#888; }
      </style>

      <!-- Header bar -->
      <div style="
        display:flex;align-items:center;height:46px;flex-shrink:0;
        background:#0f2340;color:#fff;
        border-bottom:1px solid rgba(255,255,255,.08);">

        <!-- Left: logo + title -->
        <div style="display:flex;align-items:center;gap:10px;padding:0 16px;flex:1;min-width:0;">
          <div style="
            width:26px;height:26px;background:#f59e0b;border-radius:5px;
            display:flex;align-items:center;justify-content:center;
            font-weight:900;font-size:11px;color:#0f2340;flex-shrink:0;">OL</div>
          <div style="min-width:0;">
            <div style="font-size:13px;font-weight:700;overflow:hidden;
                        text-overflow:ellipsis;white-space:nowrap;">${esc(note.title)}</div>
            <div style="font-size:10px;opacity:.45;margin-top:1px;">
              ${isViewOnly
                ? 'VIEW ONLY &mdash; Downloading not permitted'
                : 'View &amp; Download'}</div>
          </div>
        </div>

        <!-- Center: PDF controls -->
        ${pdfControls}

        <!-- Right: download + close -->
        <div style="display:flex;align-items:center;gap:8px;padding:0 14px;flex-shrink:0;">
          ${dlBtn}
          <button onclick="closeNoteViewer()" class="vtbtn"
                  style="font-size:18px;width:30px;height:30px;"
                  title="Close">&times;</button>
        </div>
      </div>

      <!-- Body -->
      <div id="viewerBody" style="flex:1;position:relative;overflow:hidden;background:#2a2a2a;">
        ${bodyHtml}
        ${watermarkHtml}
        ${shieldHtml}
      </div>
    `;

    document.body.appendChild(overlay);

    // ── Load PDF.js if needed ────────────────────────────────────────────
    if (ft === PDF_TYPE) {
      _loadPdfJs(() => _initPdf(note.id));
    }

    if (isViewOnly) _applyViewOnlyProtections(overlay, ft);
  };

  // ── PDF.js loader ────────────────────────────────────────────────────────
  function _loadPdfJs(cb) {
    if (window.pdfjsLib) { cb(); return; }
    const s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
    s.onload = () => {
      window.pdfjsLib.GlobalWorkerOptions.workerSrc =
        'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
      cb();
    };
    document.head.appendChild(s);
  }

  // ── PDF rendering ────────────────────────────────────────────────────────
  async function _initPdf(noteId) {
    const canvas = document.getElementById('pdfCanvas');
    if (!canvas) return;
    canvas.innerHTML = '';

    try {
      // Fetch via XHR so cookies (session auth) are sent
      const response = await fetch(`/api/notes/${noteId}/view`, { credentials: 'include' });
      if (!response.ok) {
        _pdfError('Failed to load document (' + response.status + ')');
        return;
      }
      const arrayBuffer = await response.arrayBuffer();

      const loadingTask = window.pdfjsLib.getDocument({ data: arrayBuffer });
      _pdfDoc = await loadingTask.promise;
      _pageCount = _pdfDoc.numPages;
      _pageNum   = 1;

      _updatePdfUI();
      await _renderPage(_pageNum);
    } catch (err) {
      console.error('PDF load error:', err);
      _pdfError('Error loading PDF: ' + (err.message || err));
    }
  }

  async function _renderPage(num) {
    if (!_pdfDoc) return;
    const canvas = document.getElementById('pdfCanvas');
    if (!canvas) return;

    // Cancel previous render if still running
    if (_renderTask) {
      _renderTask.cancel();
      _renderTask = null;
    }

    const page = await _pdfDoc.getPage(num);

    // Calculate scale to fit container width, then apply zoom scale
    const container = document.getElementById('pdfScrollContainer');
    const containerWidth = container ? container.clientWidth - 32 : 800;
    const viewport0 = page.getViewport({ scale: 1 });
    const autoScale = containerWidth / viewport0.width;
    const finalScale = autoScale * _scale;

    const viewport = page.getViewport({ scale: finalScale });
    const ctx = canvas.getContext('2d');

    canvas.width  = viewport.width;
    canvas.height = viewport.height;

    const renderContext = {
      canvasContext: ctx,
      viewport:      viewport
    };

    try {
      _renderTask = page.render(renderContext);
      await _renderTask.promise;
      _renderTask = null;

      // Scroll back to top on page change
      if (container) container.scrollTop = 0;
    } catch (err) {
      if (err?.name !== 'RenderingCancelledException') {
        console.error('Render error:', err);
      }
    }
  }

  function _updatePdfUI() {
    const pi = document.getElementById('pageInfo');
    const zl = document.getElementById('zoomLabel');
    const pp = document.getElementById('prevPage');
    const np = document.getElementById('nextPage');
    if (pi) pi.textContent = `${_pageNum} / ${_pageCount}`;
    if (zl) zl.textContent = Math.round(_scale * 100) + '%';
    if (pp) pp.disabled = _pageNum <= 1;
    if (np) np.disabled = _pageNum >= _pageCount;
  }

  function _pdfError(msg) {
    const canvas = document.getElementById('pdfCanvas');
    if (!canvas) return;
    const container = document.getElementById('pdfScrollContainer');
    if (container) {
      container.innerHTML = `
        <div style="color:#f87171;padding:40px;text-align:center;font-size:14px;">
          ${esc(msg)}</div>`;
    }
  }

  // ── Public PDF controls (called from inline onclick) ─────────────────────
  window.pdfZoom = async function (delta) {
    _scale = Math.max(0.5, Math.min(3.0, _scale + delta));
    _updatePdfUI();
    await _renderPage(_pageNum);
  };

  window.pdfPrevPage = async function () {
    if (_pageNum <= 1) return;
    _pageNum--;
    _updatePdfUI();
    await _renderPage(_pageNum);
  };

  window.pdfNextPage = async function () {
    if (_pageNum >= _pageCount) return;
    _pageNum++;
    _updatePdfUI();
    await _renderPage(_pageNum);
  };

  // ── Close / download ────────────────────────────────────────────────────
  window.closeNoteViewer = function () {
    if (_renderTask) { _renderTask.cancel(); _renderTask = null; }
    _pdfDoc   = null;
    _noteId   = null;
    const ov = document.getElementById('noteViewerOverlay');
    if (ov) ov.remove();
    _removeHandlers();
  };

  window.downloadNoteFromViewer = function (noteId) {
    window.open(`/api/notes/${noteId}/download`, '_blank');
  };

  // ── View-only protections ────────────────────────────────────────────────
  let _handlers = [];

  function _applyViewOnlyProtections(overlay, ft) {
    // For PDF (canvas): block right-click on canvas directly
    if (ft === PDF_TYPE) {
      const canvas = document.getElementById('pdfCanvas');
      if (canvas) {
        const rc = e => e.preventDefault();
        canvas.addEventListener('contextmenu', rc);
        _handlers.push({ el: canvas, type: 'contextmenu', fn: rc });
      }
    }

    // Block right-click on whole overlay
    const rc2 = e => e.preventDefault();
    overlay.addEventListener('contextmenu', rc2);
    _handlers.push({ el: overlay, type: 'contextmenu', fn: rc2 });

    // Block Ctrl/Cmd + C, P, S, A, U
    const BLOCKED = new Set(['c','p','s','a','u']);
    const kd = e => {
      if ((e.ctrlKey || e.metaKey) && BLOCKED.has(e.key.toLowerCase())) {
        e.preventDefault(); e.stopPropagation();
      }
    };
    document.addEventListener('keydown', kd, true);
    _handlers.push({ el: document, type: 'keydown', fn: kd, capture: true });

    // Block text selection in overlay UI
    const ss = e => e.preventDefault();
    overlay.addEventListener('selectstart', ss);
    _handlers.push({ el: overlay, type: 'selectstart', fn: ss });

    // Shield (non-PDF only)
    const shield = document.getElementById('viewerShield');
    if (shield) {
      const rcS = e => e.preventDefault();
      shield.addEventListener('contextmenu', rcS);
      _handlers.push({ el: shield, type: 'contextmenu', fn: rcS });
    }
  }

  function _removeHandlers() {
    _handlers.forEach(({ el, type, fn, capture }) => {
      el.removeEventListener(type, fn, capture || false);
    });
    _handlers = [];
  }

  // Close on Escape
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && document.getElementById('noteViewerOverlay')) {
      closeNoteViewer();
    }
  });

  // Keyboard shortcuts for PDF (when viewer is open)
  document.addEventListener('keydown', e => {
    if (!document.getElementById('noteViewerOverlay')) return;
    if (e.key === 'ArrowRight' || e.key === 'PageDown') pdfNextPage();
    if (e.key === 'ArrowLeft'  || e.key === 'PageUp')   pdfPrevPage();
    if (e.key === '+' || e.key === '=') pdfZoom(+0.2);
    if (e.key === '-')                  pdfZoom(-0.2);
  });

})();
